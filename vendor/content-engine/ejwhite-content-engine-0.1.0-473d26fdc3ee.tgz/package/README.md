# `@ejwhite/content-engine`

Provider-neutral content contracts and policy runtime. Publication remains disabled unless a consumer supplies a capable matching adapter, exact-hash approval, passing QA, and explicit execution intent.

## Container-first checks

```sh
docker build --target test -t content-engine-test .
docker run --rm content-engine-test
```

The container check also packs the distributable, extracts it in isolation, imports the documented public API, and runs the packaged CLI help command.

To verify all consumer provenance locks and artifact bytes together without installing dependencies:

```sh
docker run --rm -v /Users/ejwhite/Code:/workspace:ro -w /workspace/content-engine node:22-alpine \
  node scripts/verify-consumer-compatibility.mjs \
  /workspace/media-mix-model /workspace/growthcast /workspace/verdant-marketing
```

The consumers may use different deterministic archive formats, but all locks must identify the same package version and immutable package SHA-256 identifier; each archive must match its recorded SHA-256.

## API and CLI

```ts
import {
  loadConfiguration,
  parseContract,
  validateContract,
  canonicalArticleHash,
  validateEvidence,
  validateBrief,
  validateRunManifest,
} from "@ejwhite/content-engine";
```

```sh
content-engine config validate .
content-engine contract brief ./brief.json
content-engine migrate verdant ./legacy-post.json 2026-09-04T00:00:00Z
content-engine evidence validate ./article.json ./evidence.json
content-engine article hash ./article.json
content-engine qa ./article.json ./evidence.json verdant 2026-09-04T00:00:00Z . --markdown
content-engine queue template --output ./keyword-queue.csv
content-engine queue validate ./keyword-queue.csv
content-engine queue preview ./keyword-queue.csv --output ./import-preview.json
content-engine queue import ./keyword-queue.csv --store ./queue.json --preview-hash <sha256> --operator editor@example.com --commit
content-engine queue list --store ./queue.json --brand growthcast --state candidate
content-engine queue pause|resume|cancel <queue-item-id> --store ./queue.json --operator editor@example.com
content-engine queue reschedule <queue-item-id> --store ./queue.json --operator editor@example.com --at 2026-09-06T12:00:00Z
content-engine queue run-next --store ./queue.json --brand growthcast --operator worker-1 --shadow
```

Queue imports recompute the preview from the exact CSV bytes and require `--commit`, the exact preview hash, an accountable operator, and an explicit durable store path. The local store uses serialized writers and fsync-plus-atomic-rename snapshots. Shadow `run-next` claims generation work only and cannot claim scheduled publication work. Rescheduling is restricted to publication-approved/scheduled items; imports remain candidate/brief-review only.

`createBriefingSeedUploadAdapter` is a framework-neutral authenticated `text/csv` upload boundary over the same `previewBriefingSeedCsv` and `commitBriefingSeedPreview` service used by the CLI. It authenticates before reading the body, enforces declared and streamed byte limits, MIME restrictions, a required injected rate limiter, exact preview-hash and authenticated-operator gates, and returns deterministic row diagnostics. `FixedWindowUploadRateLimiter` is process-local; multi-process deployments must inject a shared limiter. The adapter never interprets spreadsheet formats or executable content.

Briefing seeds, queue items, and immutable import receipts have strict versioned JSON Schemas and can be checked with `content-engine contract briefing-seed|queue-item|import-receipt <file>`. Unknown fields fail closed.

Contract failures include JSON Pointer field paths. Configuration loading validates exact `1.0.0` policy inheritance and rejects profile attempts to weaken evidence or approval gates. Cross-field brief and run-manifest validators emit stable policy/profile findings without mutating inputs, including exact mappings for the canonical failing fixtures. QA includes conservative built-in advisories for generic observations and repeated cadence; consumers may add advisory-only validators.

## Immutable consumption without a registry

Pin a full commit SHA: `npm install 'git+ssh://git@HOST/OWNER/content-engine.git#FULL_SHA'`. npm runs the package's `prepare` script for a git dependency, compiling `dist/` from that exact checkout without requiring a package registry. Consumers that prohibit lifecycle scripts can clone at the full SHA, run the container check, create an immutable tarball with `npm run pack:git`, and install that artifact with `npm install ./ejwhite-content-engine-*.tgz --ignore-scripts`. A checked-in workspace/file dependency is also supported. Do not pin a mutable branch or tag where immutable provenance is required.

See `docs/architecture.md`, `docs/authoring.md`, `docs/migrations.md`, `docs/operations.md`, `docs/security.md`, `docs/policy-contract-handoff.md`, and `fixtures/README.md`. No runtime function performs network access or remote writes.

## Image generation configuration

The provider-neutral image API defaults fail closed and does not load `.env` files. Inject these standardized variables through the caller or deployment environment:

```text
GOOGLE_API_KEY=
IMAGE_GENERATION_PROVIDER=google
IMAGE_GENERATION_MODEL=gemini-3-pro-image
IMAGE_GENERATION_MAX_ATTEMPTS=3
```

`gemini-3-pro-image` is intentionally pinned; moving aliases and other model IDs are rejected. Tests use an injected mocked `fetch` and make no provider calls. Destination asset materialization and publication adapters are deferred.

## Deterministic fixture renderer

`renderHero`, `renderOg`, and `validateRenderedImage` provide a dependency-free, container-stable PNG renderer for shared review artifacts. It uses the checked-in procedural `Fixture Mono 5x7` test font and brand-specific geometric marks/palettes; it does not claim to contain licensed production brand fonts or final logos. OG output is exactly 1200x630, uses bounded title wrapping and conservative text/logo regions, and records deterministic binary hashes. Production visual profiles and destination materialization remain deferred.

## Asset run stages

Shared orchestration recognizes `visual-plan`, `inline-image-generation`, `hero-render`, `og-render`, `asset-validation`, and `publication-bundle` before publication preflight. Handlers remain caller-supplied and resumable; adding a stage cannot itself approve or publish. Queue template, validation, preview, durable import/list/mutation, and shadow run-next commands are local-only. Output generation refuses to overwrite files, and durable mutations require the documented explicit store/operator gates. Destination adapters remain deferred.

### Visual renderer certification

The dependency-free raster renderer is a deterministic QA fixture, not a certified production renderer. `validateRenderedImage` parses the complete PNG structure and pixel stream and deterministically checks MIME, encoded and declared dimensions, corruption/CRC, SHA-256, measured WCAG contrast, conservative crop containment, measured title bounds/minimum size, and logo clearance/collision. `certifyVisualProfile` intentionally fails closed for all three production properties until asset provenance is checked in:

- `media-mix-model`: no licensed/provenanced production font; `client/public/logo.png` has no checked-in ownership/license provenance.
- `growthcast`: `public/fonts/manrope-*.ttf`, `public/fonts/dm-mono-*.ttf`, and `public/growthcast-logo.svg` exist, but no corresponding checked-in font license or logo ownership/license provenance was found.
- `verdant`: `apps/web/public/logo.svg` requests Manrope, but no licensed font file is checked in; the logo has no checked-in ownership/license provenance.

Do not substitute system fonts, copy an asset into the package, or infer a license. Add the exact approved files plus their license/ownership provenance before changing a profile to production-ready. Destination-specific image upload/publication remains outside this package and is deferred.
