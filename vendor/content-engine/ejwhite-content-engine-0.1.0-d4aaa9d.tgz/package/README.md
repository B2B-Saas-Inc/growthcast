# `@ejwhite/content-engine`

Provider-neutral content contracts and policy runtime. Publication remains disabled unless a consumer supplies a capable matching adapter, exact-hash approval, passing QA, and explicit execution intent.

## Container-first checks

```sh
docker build --target test -t content-engine-test .
docker run --rm content-engine-test
```

## API and CLI

```ts
import {
  loadConfiguration,
  parseContract,
  validateContract,
  canonicalArticleHash,
  validateEvidence,
  validateBrief,
  validateRunManifest,
} from "@ejwhite/content-engine";
```

```sh
content-engine config validate .
content-engine contract brief ./brief.json
content-engine migrate verdant ./legacy-post.json 2026-09-04T00:00:00Z
content-engine evidence validate ./article.json ./evidence.json
content-engine article hash ./article.json
content-engine qa ./article.json ./evidence.json verdant 2026-09-04T00:00:00Z . --markdown
```

Contract failures include JSON Pointer field paths. Configuration loading validates exact `1.0.0` policy inheritance and rejects profile attempts to weaken evidence or approval gates. Cross-field brief and run-manifest validators emit stable policy/profile findings without mutating inputs, including exact mappings for the canonical failing fixtures. QA includes conservative built-in advisories for generic observations and repeated cadence; consumers may add advisory-only validators.

## Immutable consumption without a registry

Pin a full commit SHA: `npm install 'git+ssh://git@HOST/OWNER/content-engine.git#FULL_SHA'`. npm runs the package's `prepare` script for a git dependency, compiling `dist/` from that exact checkout without requiring a package registry. Consumers that prohibit lifecycle scripts can clone at the full SHA, run the container check, create an immutable tarball with `npm run pack:git`, and install that artifact with `npm install ./ejwhite-content-engine-*.tgz --ignore-scripts`. A checked-in workspace/file dependency is also supported. Do not pin a mutable branch or tag where immutable provenance is required.

See `docs/architecture.md`, `docs/authoring.md`, `docs/migrations.md`, `docs/operations.md`, `docs/security.md`, `docs/policy-contract-handoff.md`, and `fixtures/README.md`. No runtime function performs network access or remote writes.
