# GrowthCast logo asset-rights declaration

**Declarant:** EJ White  
**Declaration date:** 2026-09-06  
**Asset:** `logos/growthcast-logo.svg`  
**SHA-256:** `249a969041f9f52087bdfa764320b0b44cd9d71536c5cf0b968138015eaafb9c`

I, EJ White, declare that I own or control the rights required to use this exact GrowthCast logo asset. I authorize its inclusion in the canonical shared visual-asset package and its reproduction, transformation, compositing, cropping, and distribution in generated GrowthCast editorial images, article heroes, thumbnails, Open Graph/Twitter cards, social previews, and responsive crop variants.

This authorization applies only to the exact bytes identified by the SHA-256 above and does not grant third parties ownership of, or a general trademark license in, the GrowthCast identity. A changed or substituted logo requires a new hash-bound declaration before production certification.
