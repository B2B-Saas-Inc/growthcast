# GrowthCast font provenance

These files are byte-for-byte copies of the fonts checked in under `public/fonts/` in the GrowthCast repository. They were vendored for deterministic shared-renderer integration; they are not substitutes or downloaded lookalikes.

Source repository history:

- GrowthCast commit `dc216552be35a7cee60d9bcb2b4eaad9d08376f5` introduced the six local files on 2026-08-05.
- The SFNT name records in each Manrope binary identify “Copyright 2019 The Manrope Project Authors”, version 4.504, source `https://github.com/sharanda/manrope`, and the SIL Open Font License URL `http://scripts.sil.org/OFL`.
- The SFNT name records in each DM Mono binary identify “Copyright 2020 The DM Mono Project Authors”, version 1.000, source `https://www.github.com/googlefonts/dm-mono`, and the SIL Open Font License URL `http://scripts.sil.org/OFL`.

The binaries and their expected SHA-256 identities are checked by `test/renderer.test.ts`. This record certifies only the font provenance represented by the checked-in files and their embedded metadata. It makes no claim about GrowthCast’s logo ownership, and browser no-fallback certification remains a separate gate.

| File                    | SHA-256                                                            |
| ----------------------- | ------------------------------------------------------------------ |
| `fonts/dm-mono-400.ttf` | `c97fcd822f825e9e731867b650a39ee678b609bead29385e320171b573ec0910` |
| `fonts/dm-mono-500.ttf` | `dd60d0861a3efd540efc3f2f85e7a7fd69a7ece7eadf44aaffa5fc5c86adda0e` |
| `fonts/manrope-400.ttf` | `a13d9b41b0a471ce58f0e46d377fa3cc76615e4632c3b15eb397caadf7a13f0a` |
| `fonts/manrope-500.ttf` | `f433e5d333be1128d8ec8a28b8aadd0314d10e14e4105406076666bc830fc15d` |
| `fonts/manrope-600.ttf` | `6bad1a774228464cc88b8b0271555b266f7a3c64a7bedf15e165fdab4f6ac0ce` |
| `fonts/manrope-700.ttf` | `b9584e099e0e7f1e1e914c3037aabb9010c50346a3ce8df5eeeeecc0563044d8` |

## Canonical upstream supersession

The canonical shared package now vendors authoritative pinned Manrope bytes and the unmodified OFL license in `../fonts/manrope/`; see `../fonts/FONT-PROVENANCE.md`. Those canonical bytes supersede the consumer-copy Manrope files above for future production profile binding. The legacy DM Mono copies remain documented but do not substitute for the separately requested canonical JetBrains Mono family. Profile hash binding and renderer no-fallback proof remain unresolved.
