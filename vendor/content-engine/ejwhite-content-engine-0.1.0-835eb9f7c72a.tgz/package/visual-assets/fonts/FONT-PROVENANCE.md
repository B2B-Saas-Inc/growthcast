# Canonical production font provenance

Retrieved 2026-09-06 from the official Google Fonts upstream distribution repository (`https://github.com/google/fonts`) using read-only Git. The exact repository commit is `5e35378e6bda803962ee6fd257e444a7d459660d` (committed 2026-09-04T11:48:05-07:00). Google Fonts records each family under its SIL Open Font License (`ofl`) directory and records the family upstream in its checked-in metadata.

The raw URLs below are immutable because they contain the full commit. The checked-in binaries and license texts are byte-for-byte copies; no subsetting, conversion, hinting, or license modification was performed.

| Family         | Vendored file                            | Immutable official source URL                                                                                                           | SHA-256                                                            |
| -------------- | ---------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------ |
| Work Sans      | `work-sans/WorkSans[wght].ttf`           | `https://raw.githubusercontent.com/google/fonts/5e35378e6bda803962ee6fd257e444a7d459660d/ofl/worksans/WorkSans%5Bwght%5D.ttf`           | `f50f61f2ba738e239442d40bf1069adb195c224b6a5a73a581fc2f3ed62a9f63` |
| JetBrains Mono | `jetbrains-mono/JetBrainsMono[wght].ttf` | `https://raw.githubusercontent.com/google/fonts/5e35378e6bda803962ee6fd257e444a7d459660d/ofl/jetbrainsmono/JetBrainsMono%5Bwght%5D.ttf` | `48715a42ec242c21e9f02692891e147d022299a52e48d5e413e1a942193ffeda` |
| Manrope        | `manrope/Manrope[wght].ttf`              | `https://raw.githubusercontent.com/google/fonts/5e35378e6bda803962ee6fd257e444a7d459660d/ofl/manrope/Manrope%5Bwght%5D.ttf`             | `d0639be45d0af36e798172419d7bd173c4bd4f29e2b76cbb69db1d11bf8b0a40` |
| Inter          | `inter/Inter[opsz,wght].ttf`             | `https://raw.githubusercontent.com/google/fonts/5e35378e6bda803962ee6fd257e444a7d459660d/ofl/inter/Inter%5Bopsz%2Cwght%5D.ttf`          | `29160a80ff49ddcab2c97711247e08b1fab27a484a329ce8b813d820dc559031` |

## Unmodified licenses

| Family         | Vendored license         | Immutable official source URL                                                                                       | SHA-256                                                            |
| -------------- | ------------------------ | ------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------ |
| Work Sans      | `work-sans/OFL.txt`      | `https://raw.githubusercontent.com/google/fonts/5e35378e6bda803962ee6fd257e444a7d459660d/ofl/worksans/OFL.txt`      | `749aca05078664ce682dce1b1b10096ac397cb088c1a6df4e1bb56f0092a9272` |
| JetBrains Mono | `jetbrains-mono/OFL.txt` | `https://raw.githubusercontent.com/google/fonts/5e35378e6bda803962ee6fd257e444a7d459660d/ofl/jetbrainsmono/OFL.txt` | `b2fe5e8987594e9ffd1d2ca52a2f5d73eb8335243893c5d6254b5ad69269591d` |
| Manrope        | `manrope/OFL.txt`        | `https://raw.githubusercontent.com/google/fonts/5e35378e6bda803962ee6fd257e444a7d459660d/ofl/manrope/OFL.txt`       | `e01b637272e0cbdfb240184dd98ea5cc671556d9894dae2668d92ab2c906787c` |
| Inter          | `inter/OFL.txt`          | `https://raw.githubusercontent.com/google/fonts/5e35378e6bda803962ee6fd257e444a7d459660d/ofl/inter/OFL.txt`         | `5b9321a4298cfeb6b34354164a1c3afc3db114569984c502b9b35d988fd58c57` |

The Google Fonts metadata at this pinned commit identifies the underlying family repositories as Work Sans (`weiweihuanghuang/Work-Sans`), JetBrains Mono (`JetBrains/JetBrainsMono`), Manrope (historical `sharanda/manrope`; the distributed binary is retained by Google Fonts), and Inter (`rsms/inter`). The canonical package pins the official distributed bytes above rather than relying on moving branch heads or runtime font delivery.

Vendoring and provenance alone do not certify production rendering. Each production profile must separately bind the required files and licenses by SHA-256, and the renderer must prove that it loaded these bytes without fallback.
