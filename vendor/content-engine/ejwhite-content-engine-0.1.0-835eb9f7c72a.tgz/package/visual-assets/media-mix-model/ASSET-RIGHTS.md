# Media Mix Model logo asset-rights declaration

**Declarant:** EJ White  
**Declaration date:** 2026-09-06  
**Asset:** `logos/logo.png`  
**SHA-256:** `2c27180873b1c0e1f8276257dd525a65acd7dbe6d5542bed666a320b57ff6e98`

I, EJ White, declare that I own or control the rights required to use this exact Media Mix Model logo asset. I authorize its inclusion in the canonical shared visual-asset package and its reproduction, transformation, compositing, cropping, and distribution in generated Media Mix Model editorial images, article heroes, thumbnails, Open Graph/Twitter cards, social previews, and responsive crop variants.

This authorization applies only to the exact bytes identified by the SHA-256 above and does not grant third parties ownership of, or a general trademark license in, the Media Mix Model identity. A changed or substituted logo requires a new hash-bound declaration before production certification.
