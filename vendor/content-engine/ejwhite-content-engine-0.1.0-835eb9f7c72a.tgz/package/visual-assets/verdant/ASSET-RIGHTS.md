# Verdant logo asset-rights declaration

**Declarant:** EJ White  
**Declaration date:** 2026-09-06  
**Asset:** `logos/logo.svg`  
**SHA-256:** `daef86cb5cfecc3cb8cd56d05a8097a4af79f76839cb9eadadd0d94e3c510c9f`

I, EJ White, declare that I own or control the rights required to use this exact Verdant logo asset. I authorize its inclusion in the canonical shared visual-asset package and its reproduction, transformation, compositing, cropping, and distribution in generated Verdant editorial images, article heroes, thumbnails, Open Graph/Twitter cards, social previews, and responsive crop variants.

This authorization applies only to the exact bytes identified by the SHA-256 above and does not grant third parties ownership of, or a general trademark license in, the Verdant identity. A changed or substituted logo requires a new hash-bound declaration before production certification.
